#include "main.h"
// Function to create a database from the list of files
int Create_database(main_node *arr[],Slist *filename)
{
	// Iterate through each file in the linked list
	while(filename!= NULL)
	{
		char f_name[50];
		strcpy(f_name,filename->file_name);
		FILE *fptr = fopen(f_name,"r");
		char current_word[256];

		// Read each word from the file
		while(fscanf(fptr,"%255s",current_word)!=EOF)
		{
			int ind;
			//printf("string ==>%s\n",current_word);
			char ch=current_word[0];

			// Determine the index for the word based on its first character
			if(islower(ch))
			{
				ind=ch%97;
			}
			else if(isupper(ch))
			{
				ind=ch%65;
			}
			else
			{
				ind=26;
			}

			// If there is no main node at the index, create a new one
			if(arr[ind] == NULL)
			{
				//creation of new main node
				main_node *new_main_node=malloc(sizeof(main_node));
				if(new_main_node == NULL)
				{
					printf("Error: new nodes are not created\n");
					return FAILURE;
				}
				new_main_node->file_count = 1;
				strcpy(new_main_node->word,current_word);

				//creation of new sub node
				sub_node *new_sub_node=malloc(sizeof(sub_node));
				new_sub_node->word_count=1;
				strcpy(new_sub_node->fname,filename->file_name);

				//updating the link part
				new_main_node->main_link = NULL;
				new_sub_node->sub_link=NULL;
				new_main_node->sub_link=new_sub_node;

				//update in database
				arr[ind]=new_main_node;
			}
			else
			{
				main_node *temp = arr[ind];
				main_node *prev=NULL;
				int flag=0;
				while(temp)
				{
					prev = temp;
					if(strcmp(temp->word,current_word)==0)  //if word is present !!!!!!!! 
					{
						flag++;
						sub_node *tempword = temp->sub_link;
						sub_node *prevword=NULL;
						while(tempword){
							if(strcmp(tempword->fname,filename->file_name)==0) //if file name is same !!!!!!!!
							{
								tempword->word_count++;
								break;
							}
							else
							{
								prevword=tempword;
								tempword=tempword->sub_link;
							}
						}
						if(tempword == NULL){
							//creation of new sub node
							sub_node *new_sub_node=malloc(sizeof(sub_node));
							new_sub_node->word_count=1;
							strcpy(new_sub_node->fname,filename->file_name);
							prevword->sub_link=new_sub_node;
							temp->file_count++;
							new_sub_node->sub_link=NULL;
						}
						break;
					}
					temp=temp->main_link;
				}
				if(flag==0)
				{
					//creation of new main node
					main_node *new_main_node=malloc(sizeof(main_node));
					if(new_main_node == NULL)
					{
						printf("Error: new nodes are not created\n");
						return FAILURE;
					}
					new_main_node->file_count=1;
					strcpy(new_main_node->word,current_word);

					//creation of new sub node
					sub_node *new_sub_node=malloc(sizeof(sub_node));
					new_sub_node->word_count=1;
					strcpy(new_sub_node->fname,filename->file_name);

					//updating the link part
					new_main_node->main_link = NULL;
					new_sub_node->sub_link=NULL;
					new_main_node->sub_link=new_sub_node;

					prev->main_link=new_main_node;
				}
			}
		}
		fclose(fptr);
		filename=filename->link;
	}
	return SUCCESS;
}
