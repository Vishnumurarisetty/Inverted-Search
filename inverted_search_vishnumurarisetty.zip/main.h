#ifndef MAIN_H
#define MAIN_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include<ctype.h>

// Macros to represent success and failure status codes
#define SUCCESS 0
#define FAILURE 1

// Structure for singly linked list node to store file names
typedef struct Slist
{
	char file_name[256];
	struct Slist *link;
}Slist;


// Structure for sub-node in the main data structure
typedef struct sub_node
{
	char fname[256];
	int word_count;
	struct sub_node *sub_link;
}sub_node;

// Structure for main node in the main data structure
typedef struct main_node
{
	char word[256];
	int file_count;
	struct sub_node *sub_link;
	struct main_node *main_link;
}main_node;



// Function to validate command-line arguments
int validate(int argc, char *argv[], Slist **filename);

// Function to insert a new file name at the end of the singly linked list
int insert_at_last(Slist **filename, char *data);

// Function to print the list of file names
int print_list(Slist *filename);

// Function to create a database from the list of file names
int Create_database(main_node *arr[],Slist *filename);

// Function to search for a word in the database
int search_database(main_node *arr[],char* data);

// Function to display the entire database
int display_database(main_node *arr[]);

// Function to save the current state of the database to a file
int save_database(main_node *arr[]);

// Function to update the database from a backup file
int update_database(main_node *arr[],Slist **backup_fname);

// Function to insert a file name into the singly linked list if not already present
int insert_last(char *,Slist **);

// Function to compare the backup file names with the current file names
void compare(Slist *,Slist **);



#endif

