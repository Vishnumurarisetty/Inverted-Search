#include"main.h"


int search_database(main_node *arr[],char* data)
{
	int ind;
	char ch=data[0];

	//Determine the index based on the first character of the search word
	if(islower(ch))
	{
		ind=ch%97;
	}
	else if(isupper(ch))
	{
		ind=ch%65;
	}
	else
	{
		ind=26;
	}

	main_node *temp=arr[ind];
	if(temp==NULL)
		return FAILURE;
	printf("---------------------------------------------------\n");

	// Traverse the main nodes in the list
	while(temp!=NULL)
	{
		// Compare the current word with the search word
		if(strcmp(temp->word,data) == 0)
		{
			sub_node *sub = temp->sub_link;
			printf("The word %s is present in %d files\n",data,temp->file_count);
			// Print the details of all sub nodes (files) where the word is present
			for(int i=0;i<temp->file_count;i++)
			{
				printf("file name : %s   word count : %d\n",sub->fname,sub->word_count);
				sub=sub->sub_link;
			}
			printf("---------------------------------------------------\n");
			return SUCCESS;
		}
		temp=temp->main_link; // Move to the next main node
	}
	return FAILURE;
}


