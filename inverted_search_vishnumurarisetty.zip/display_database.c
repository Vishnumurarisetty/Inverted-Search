#include"main.h"

int display_database(main_node *arr[])
{
	printf("____________________________________________________\n");
	printf("Index     word      filecount filename  wordcount\n");
	printf("----------------------------------------------------\n");

	// Iterate through each index in the array
	for(int i=0;i<27;i++)
	{
		if(arr[i] != NULL)
		{
			main_node *temp=arr[i];

			// Traverse the main nodes at the current index
			while(temp != NULL)
			{
				// Print the main node details (index, word, file count)
				printf(" %-2d%11s%10d",i,temp->word,temp->file_count);
				sub_node *flag=temp->sub_link;
				int var=0;
				// Traverse the sub nodes linked to the current main node
				while(flag!=NULL)
				{
					if(var == 0)
					{
						printf("%12s%8d\n",flag->fname,flag->word_count);
						var++;
					}
					else
					{
						printf("%36s%8d\n",flag->fname,flag->word_count);
					}
					// Move to the next sub node
					flag=flag->sub_link;

				}
				// Move to the next main node
				temp=temp->main_link;
			}
		}
	}
	printf("---------------------------------------------------\n");
	return SUCCESS;



}

