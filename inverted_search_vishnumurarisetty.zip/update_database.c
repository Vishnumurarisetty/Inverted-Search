//including the required header files
#include"main.h"

int update_database(main_node *arr[],Slist **backup_fname)
{
	char backup[50];
	printf("Enter the backup file: ");
	scanf("%s", backup);

	// Check if the backup file has a .txt extension
	if (strstr(backup, ".txt") == NULL)
	{
		return FAILURE;
	}

	// Try to open the backup file
	FILE *fptr = fopen(backup, "r");
	if (fptr == NULL)
	{
		printf("Failed to open file\n");
		return FAILURE;
	}

	// Check if the first and last characters in the file are the same
	char first = fgetc(fptr);
	fseek(fptr, -2, SEEK_END);
	char last = fgetc(fptr);

	if (first == last)
	{
		fseek(fptr, 0, SEEK_SET); // Rewind the file pointer to the beginning
		char str[200];

		//Read the file line by line
		while(fscanf(fptr,"%s",str) != EOF)
		{
			int ind = atoi(strtok(str, "#;"));
			if(strtok == NULL)
				break;
			char word[20];
			char *token = strtok(NULL, "#;");
			if(token == NULL)
			{
				break;
			}
			strcpy(word,token);
			int file_count = atoi(strtok(NULL, "#;"));

			// Create a new main node
			main_node *temp = malloc(sizeof(main_node));
			if(temp == NULL)
			{
				fclose(fptr);
				return FAILURE;
			}
			temp->file_count = file_count;
			strcpy(temp->word, word);
			temp->sub_link = NULL;
			temp->main_link = NULL;
			//int flag=0;

			// Loop to add sub nodes (file details) to the main node
			for (int i = 0; i < file_count; i++)
			{
				char fname[20];
				token = strtok(NULL, "#;");
				if(token == NULL)
				{
					free(temp);
					fclose(fptr);
					return FAILURE;
				}

				strcpy(fname, token);
				insert_last(fname,backup_fname);
				int word_count = atoi(strtok(NULL, "#;"));

				sub_node *new_temp = malloc(sizeof(sub_node));
				if(new_temp == NULL)
				{
					free(temp);
					fclose(fptr);
					return FAILURE;
				}
				new_temp->word_count = word_count;
				strcpy(new_temp->fname, fname);

				new_temp->sub_link = NULL;

				// Attach the sub node to the main node
				if(temp->sub_link == NULL)
				{
					temp->sub_link = new_temp;
				}
				else
				{
					sub_node *prev = temp->sub_link;
					while (prev->sub_link != NULL)
					{
						prev = prev->sub_link;
					}
					prev->sub_link = new_temp;				
				}
			}

			// Attach the main node to the array
			if (arr[ind] == NULL)
			{
				arr[ind] = temp;
			}
			else
			{
				main_node *temp1 = arr[ind];
				while (temp1->main_link != NULL)
				{
					temp1 = temp1->main_link;
				}
				temp1->main_link = temp;
			}
		}
	}
	else
	{
		printf("ERROR: not a backup file\n");
		fclose(fptr);
		return FAILURE;
	}

	fclose(fptr);
	return SUCCESS;
}

// Function to insert a file name at the end of the list
int insert_last(char *data,Slist **filename)
{

	if (data == NULL || filename == NULL)
	{
		return FAILURE;
	}

	Slist *new = malloc(sizeof(Slist));
	if (new == NULL)
	{
		return FAILURE;
	}
	strcpy(new->file_name, data);
	new->link = NULL;

	if (*filename == NULL)
	{
		*filename = new;
		return SUCCESS;
	}

	Slist *temp = *filename;
	while (temp->link != NULL)
	{
		if (strcmp(temp->file_name, data) == 0)
		{
			free(new);
			return SUCCESS;
		}
		temp = temp->link;
	}

	temp->link = new;
	return SUCCESS;
}
