/*
Name: Vishnu murarisetty
Date: 5/6/24
Project: DataStructures
Title:Inverted Search
 */

//including the required header files
#include "main.h"

// Validate function to check file existence, format, and non-empty status
int validate(int argc, char* argv[], Slist **filename) 
{
	printf("\n");
	for (int i = 1; i < argc; i++) 
	{
		if (strstr(argv[i], ".txt") != NULL) // Check if file has a .txt extension
		{
			FILE *file_ptr = fopen(argv[i], "r");
			if (file_ptr != NULL) // Check if file is non-empt
			{
				//moving the cursor from 0 to end
				fseek(file_ptr, 0, SEEK_END);
				if (ftell(file_ptr) > 0) 
				{
					//closing the file pointer
					fclose(file_ptr);
					int count = 0;
					Slist *temp = *filename;
					while (temp != NULL)
					{
						if (strcmp(temp->file_name, argv[i]) == 0) // Check for duplicate files
						{
							count = 1;
							break;
						}
						//traversing the temp to the next node
						temp = temp->link;
					}
					if (count == 0) 
					{
						if (insert_at_last(filename, argv[i]) != SUCCESS) 
						{
							printf("ERROR: Inserting file name failed\n");//prinitng the error
							return FAILURE;
						}
					}
					else
					{
						printf("ERROR: %s similar files are not allowed\n",argv[i]);
					}
				} 
				else 
				{
					printf("ERROR : %s file is Empty\n",argv[i]);
					fclose(file_ptr);
				}
			}
			else
			{
				printf("ERROR: %s file does not exist\n",argv[i]);
			}


		}
		else
		{
			printf("ERROR : %s file is not .txt file\n",argv[i]);
		}
	}
	return SUCCESS;
}

// Main function
int main(int argc, char* argv[]) 
{
	//counting the no of arguments
	if (argc < 2) 
	{
		printf("ERROR: Please pass file names\n");
		return 1;
	}

	Slist *filename = NULL;
	if (validate(argc, argv, &filename) == SUCCESS) 
	{
		printf("\nINFO : Validate function is successfull\n");
		print_list(filename);
	}
	else 
	{
		printf("\nERROR : Validate function FAILURE\n");

	}
	main_node *arr[28]={NULL}; // Initialize array of main_node pointers          
	Slist *backup_fname = NULL;

	while(1)
	{

		printf("\n1.Create database\n2.Display database\n3.Search database\n4.Save database\n5.Update database\n6.exit\n");

		int choice;
		printf("\nselect one option: ");
		if (scanf("%d", &choice) != 1)
		{
			printf("\n---------------------------------------------------\n");
			printf("ERROR : enter proper option!!! \n");
			printf("---------------------------------------------------\n");
			// Clear the input buffer
			while (getchar() != '\n');
			continue;
		}

		// Clear the input buffer after a successful scanf to handle any remaining characters
		while (getchar() != '\n');

		printf("\n");
		// Track if the database has been created
		static int flag=0;
		static int temp=0;
		static int temp2=1;

		switch(choice)
		{
			case 1: 
				//printf("Create database selected\n");
				if(backup_fname != NULL)
				{
					compare(backup_fname,&filename);
					backup_fname=NULL;
				}
				temp=1;


				if(flag ==0)
				{
					if(Create_database(arr,filename) == SUCCESS)
					{
						printf("---------------------------------------------------\n");
						printf("INFO : Data created succesfull\n");
						printf("---------------------------------------------------\n");
						flag++;
					}
				}
				else
				{
					printf("---------------------------------------------------\n");
					printf("ERROR : Data base already created.\n");
					printf("---------------------------------------------------\n");
				}
				temp2=0;
				break;
			case 2:
				// Handle database saving
				if(temp2 == 0)
				{
					if(display_database(arr) == SUCCESS)
					{
						//printf("INFO : Database is successfully displayed\n");
					}
				}
				else
				{
					printf("---------------------------------------------------\n");
					printf("ERROR : Database is  not created or updated\n");
					printf("---------------------------------------------------\n");
				}
				break;
			case 3:
				//printf("Search database selected\n");
				char data[50];
				printf("Enter the word to be searched : ");
				scanf("%s",data);
				if(search_database(arr,data) != SUCCESS)
				{
					printf("---------------------------------------------------\n");
					printf("INFO : Word is not present in any files \n");
					printf("---------------------------------------------------\n");
				}
				break;
			case 4:
				//printf("Save database selected\n");

				if(save_database(arr) == SUCCESS)
				{
					printf("---------------------------------------------------\n");
					printf("INFO : Database is saved successfully\n");
					printf("---------------------------------------------------\n");
				}
				else
				{
					printf("---------------------------------------------------\n");
					printf("ERROR : please pass the valid backup file\n");
					printf("---------------------------------------------------\n");
				}
				break;
			case 5:
				if( temp!=0)
				{
					printf("---------------------------------------------------\n");
					printf("ERROR : Created database so unable to update\n");
					printf("---------------------------------------------------\n");

					break;
				}
				else
				{
					if(update_database(arr,&backup_fname) == SUCCESS)
					{
						printf("---------------------------------------------------\n");

						printf("INFO : updated database succesfully\n");
						printf("---------------------------------------------------\n");
					}
					else
					{
						printf("---------------------------------------------------\n");
						printf("ERROR : Already created database \n");
						printf("---------------------------------------------------\n");

					}
				}
				temp2=0;

				break;
			case 6:
				// Handle program exit
				printf("---------------------------------------------------\n");
				printf("                     EXITED                        \n");
				printf("---------------------------------------------------\n");
				return 1;
			default :
				printf("---------------------------------------------------\n");
				printf("ERROR : enter proper option!!! \n");
				printf("---------------------------------------------------\n");
		}
	}

	return 0;
}

// Insert function to add a new file name at the end of the list
int insert_at_last(Slist **filename, char *data) 
{
	Slist *new = malloc(sizeof(Slist));
	if (new == NULL) 
	{
		return FAILURE;
	}
	strcpy(new->file_name, data);
	new->link = NULL;
	if (*filename == NULL)
	{
		*filename = new;
		return SUCCESS;
	}
	Slist *temp = *filename;
	while (temp->link != NULL) 
	{
		temp = temp->link;
	}
	temp->link = new;
	return SUCCESS;
}

// Print list function to display the file names
int print_list(Slist *filename) 
{
	printf("---------------------------------------------------\n");
	if (filename == NULL) 
	{
		printf("INFO: List is empty\n");
		printf("---------------------------------------------------\n");
	} 
	else 
	{
		printf("files_list->");
		while (filename) 
		{
			printf(" %s -> ", filename->file_name);
			filename = filename->link;
		}
		printf("NULL\n");
		printf("---------------------------------------------------\n");
	}
	return SUCCESS;
}


// Compare function to remove common files between backup and current list
void compare(Slist *back,Slist **filename)
{
	Slist *temp = back;

	while(temp!=NULL)
	{
		Slist *flag = *filename;
		Slist *prev = NULL;
		while(flag!=NULL)
		{

			if(strcmp(temp->file_name,flag->file_name) == 0)
			{
				if(prev!=NULL)
				{
					prev->link=flag->link;
					free(flag);
					break;
				}
				else
				{
					*filename=flag->link;
					free(flag);
					break;
				}
			}
			prev=flag;
			flag=flag->link;
		}
		temp=temp->link;
	}
}
