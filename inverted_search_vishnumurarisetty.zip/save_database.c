#include"main.h"

int save_database(main_node *arr[])
{
	char backup[50];

	//Prompt user for backup file name
	printf("Enter backup file name : ");
	scanf("%s",backup);

	// Check if the file name ends with ".txt"
	if(strstr(backup,".txt") ==NULL)
	{
		return FAILURE;
	}	
	else
	{ 
		// Open the file for writing
		FILE *fptr = fopen(backup,"w");

		// Iterate through each index in the array
		for(int i=0;i<27;i++)
		{
			if(arr[i] != NULL)
			{
				main_node *temp = arr[i];
				// Traverse the main nodes at the current index
				while(temp!=NULL)
				{
					//Write the main node details to the file
					fprintf(fptr,"#%d;",i);
					fprintf(fptr,"%s;",temp->word);
					fprintf(fptr,"%d;",temp->file_count);
					sub_node *sub_temp=temp->sub_link;

					// Traverse and write the sub nodes linked to the current main node
					for(int i=0;i<temp->file_count;i++)
					{
						fprintf(fptr,"%s;",sub_temp->fname);
						fprintf(fptr,"%d;",sub_temp->word_count);
						sub_temp=sub_temp->sub_link;
					}

					// End of the current main node entry
					fprintf(fptr,"%s\n","#");
					temp=temp->main_link;
				}
			}	
			//printf("\n");	
		}
		fclose(fptr);
	}

	return SUCCESS;
}



